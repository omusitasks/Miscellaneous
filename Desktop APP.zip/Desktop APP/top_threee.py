import tkinter as tk
from tkinter import messagebox

# Function to update the status
def update_status(message):
    status_label.config(text=message)

# Function to show the top three rankings (this is dummy data for now)
def show_top_three():
    top_three = "1. Blink Twice (6.7)\n2. The Crow (4.6)\n3. Inside Out 2 (7.7)"
    messages_label.config(text="Most-Pirated Online Movies (title and IMDb rating):\n" + top_three)

# Function to show data source (placeholder)
def show_data_source():
    messagebox.showinfo("Data Source", "Displaying data from an example source")

# Function to save a winner (Gold/Silver/Bronze)
def save_winner(placement):
    update_status(f"{placement} winner saved")

# Main window setup
root = tk.Tk()
root.title("Digital Olympics - Basketball Edition")
root.geometry("400x500")  # Set window size to ensure it fits everything

# Create frames for organization
main_frame = tk.Frame(root)
main_frame.pack(padx=10, pady=10)

# Trophy podium style (all trophies on the same base level)
trophy_frame = tk.Frame(main_frame)
trophy_frame.grid(row=0, column=0, columnspan=3, pady=10)

# Podium arrangement for trophies (remove padding between them)
silver_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 50), fg="silver")
silver_label.grid(row=1, column=0, sticky="s")  # Left, aligned at bottom

gold_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 70), fg="gold")
gold_label.grid(row=0, column=1, rowspan=2, sticky="s")  # Center, aligned at bottom

bronze_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 50), fg="brown")
bronze_label.grid(row=1, column=2, sticky="s")  # Right, aligned at bottom

# Remove padding between the trophies
trophy_frame.grid_columnconfigure(0, minsize=0)
trophy_frame.grid_columnconfigure(1, minsize=0)
trophy_frame.grid_columnconfigure(2, minsize=0)

# Numbers for podium (display the positions below the trophies)
silver_position = tk.Label(trophy_frame, text="2", font=("Arial", 30), fg="gray")
silver_position.grid(row=2, column=0, padx=0, pady=(0, 10))

gold_position = tk.Label(trophy_frame, text="1", font=("Arial", 30), fg="gold")
gold_position.grid(row=2, column=1, padx=0, pady=(0, 10))

bronze_position = tk.Label(trophy_frame, text="3", font=("Arial", 30), fg="brown")
bronze_position.grid(row=2, column=2, padx=0, pady=(0, 10))

# Frame for rankings and save winner options
ranking_winner_frame = tk.Frame(main_frame)
ranking_winner_frame.grid(row=1, column=0, columnspan=2, pady=10)

# Choose and view ranking section
ranking_frame = tk.Frame(ranking_winner_frame)
ranking_frame.grid(row=0, column=0, padx=20)

ranking_var = tk.StringVar(value="Most-Pirated Online Movies")
ranking_options = [
    ("Top-Rating iTunes TV Episodes", "Top-Rating iTunes TV Episodes"),
    ("Most-Pirated Online Movies", "Most-Pirated Online Movies"),
    ("Top-Selling Pop Songs in the UK", "Top-Selling Pop Songs in the UK")
]

ranking_label = tk.Label(ranking_frame, text="Choose and view a ranking:")
ranking_label.pack(anchor="w", pady=5)

for text, value in ranking_options:
    tk.Radiobutton(ranking_frame, text=text, variable=ranking_var, value=value).pack(anchor="w")

# Buttons for showing top three and data source in one row
button_frame = tk.Frame(ranking_frame)
button_frame.pack(pady=5)

tk.Button(button_frame, text="Show top three", command=show_top_three).pack(side="left", padx=10)
tk.Button(button_frame, text="Show data source", command=show_data_source).pack(side="left", padx=10)

# Save a winner section
save_winner_frame = tk.Frame(ranking_winner_frame)
save_winner_frame.grid(row=0, column=1, padx=20)

save_winner_label = tk.Label(save_winner_frame, text="Save a winner:")
save_winner_label.pack(anchor="w", pady=5)

tk.Button(save_winner_frame, text="Gold", command=lambda: save_winner("Gold")).pack(side="top", pady=2)
tk.Button(save_winner_frame, text="Silver", command=lambda: save_winner("Silver")).pack(side="top", pady=2)
tk.Button(save_winner_frame, text="Bronze", command=lambda: save_winner("Bronze")).pack(side="top", pady=2)

# Messages and status section
messages_frame = tk.Frame(main_frame)
messages_frame.grid(row=2, column=0, columnspan=2, pady=10)

messages_label = tk.Label(messages_frame, text="Most-Pirated Online Movies (title and IMDb rating):", justify="left")
messages_label.pack(anchor="w", pady=5)

status_label = tk.Label(root, text="Status: Ready", fg="blue")
status_label.pack(pady=5)

# Start the application
root.mainloop()



# import tkinter as tk
# from tkinter import messagebox

# def show_top_three():
#     # Simulate showing the top three in a messagebox
#     messagebox.showinfo("Top Three", "1. Blink Twice (6.7)\n2. The Crow (4.6)\n3. Inside Out 2 (7.7)")

# def show_data_source():
#     # Simulate showing the data source in a messagebox
#     messagebox.showinfo("Data Source", "Most-Pirated Online Movies")

# def save_winner(position):
#     # Simulate saving a winner's details
#     messagebox.showinfo("Save Winner", f"{position} winner saved!")

# # Create the main window
# root = tk.Tk()
# root.title("Digital Olympics")
# root.geometry("616x856")
# root.configure(bg="lightyellow")

# # Create the trophy images (placeholders)
# trophy_frame = tk.Frame(root, bg="lightyellow")
# trophy_frame.pack(pady=20)

# tk.Label(trophy_frame, text="🥈", font=("Arial", 64), bg="lightyellow").grid(row=0, column=0, padx=10)
# tk.Label(trophy_frame, text="🥇", font=("Arial", 64), bg="lightyellow").grid(row=0, column=1, padx=10)
# tk.Label(trophy_frame, text="🥉", font=("Arial", 64), bg="lightyellow").grid(row=0, column=2, padx=10)

# # Create the options section
# options_frame = tk.Frame(root, bg="lightyellow", pady=10)
# options_frame.pack(pady=10)

# tk.Label(options_frame, text="Choose and view a ranking", font=("Arial", 12), bg="lightyellow").grid(row=0, column=0, sticky="w")

# ranking_var = tk.StringVar(value="Most-Pirated Online Movies")
# rankings = ["Top-Rating iTunes TV Episodes", "Most-Pirated Online Movies", "Top-Selling Pop Songs in the UK"]

# for idx, ranking in enumerate(rankings):
#     tk.Radiobutton(options_frame, text=ranking, variable=ranking_var, value=ranking, bg="lightyellow").grid(row=idx+1, column=0, sticky="w")

# # Create buttons to show top three and data source
# btn_frame = tk.Frame(options_frame, bg="lightyellow")
# btn_frame.grid(row=4, column=0, pady=10)

# tk.Button(btn_frame, text="Show top three", command=show_top_three).grid(row=0, column=0, padx=5)
# tk.Button(btn_frame, text="Show data source", command=show_data_source).grid(row=0, column=1, padx=5)

# # Create the save winner section
# save_frame = tk.Frame(root, bg="lightyellow", pady=10)
# save_frame.pack(pady=10)

# tk.Label(save_frame, text="Save a winner", font=("Arial", 12), bg="lightyellow").grid(row=0, column=0, sticky="w")

# tk.Button(save_frame, text="Gold", command=lambda: save_winner("Gold")).grid(row=1, column=0, padx=5, pady=5, sticky="w")
# tk.Button(save_frame, text="Silver", command=lambda: save_winner("Silver")).grid(row=2, column=0, padx=5, pady=5, sticky="w")
# tk.Button(save_frame, text="Bronze", command=lambda: save_winner("Bronze")).grid(row=3, column=0, padx=5, pady=5, sticky="w")

# # Create the messages section
# message_frame = tk.Frame(root, bg="lightyellow", pady=10)
# message_frame.pack(pady=10)

# tk.Label(message_frame, text="Messages", font=("Arial", 12), bg="lightyellow").grid(row=0, column=0, sticky="w")
# message_label = tk.Label(message_frame, text="Most-Pirated Online Movies (title and IMDb rating):\n1. Blink Twice (6.7)\n2. The Crow (4.6)\n3. Inside Out 2 (7.7)", 
#                          font=("Arial", 10), justify="left", bg="lightyellow")
# message_label.grid(row=1, column=0, sticky="w")

# # Run the application
# root.mainloop()
