import tkinter as tk
from tkinter import messagebox
from tkinter import Entry, Label, Button, W, END
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Progressbar

# Function to download a document from a given URL
def download(url):
    import requests
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check for HTTP errors
        return response.text  # Return the content of the document
    except Exception as e:
        print(f"Error downloading the document: {e}")
        return None

# Function to update the status
def update_status(message):
    status_label.config(text=message)

# Function to show the top three rankings (this is dummy data for now)
def show_top_three():
    top_three = "1. Blink Twice (6.7)\n2. The Crow (4.6)\n3. Inside Out 2 (7.7)"
    messages_label.config(text="Most-Pirated Online Movies (title and IMDb rating):\n" + top_three)

# Function to show data source (placeholder)
def show_data_source():
    messagebox.showinfo("Data Source", "Displaying data from an example source")

# Function to save a winner (Gold/Silver/Bronze)
def save_winner(placement):
    update_status(f"{placement} winner saved")

class OnlineDataViewer:
    def __init__(self, master):
        self.master = master
        master.title("Online Data Viewer")

        # Create a label, text field, and button for the URL
        Label(master, text="Enter the URL of the document you want to download:").grid(row=0, column=0, sticky=W)
        self.url_input = Entry(master, width=50)
        self.url_input.grid(row=0, column=1)
        Button(master, text="Download", command=self.download_document).grid(row=0, column=2)

        # Create a progress bar
        self.progress = Progressbar(master, length=200, mode='indeterminate')
        self.progress.grid(row=1, column=1)

        # Create a button to view downloaded data
        Button(master, text="View Data", command=self.display_data).grid(row=2, column=1)

        # Create a scrolled text area to display downloaded data
        self.text_area = ScrolledText(master, width=70, height=20)
        self.text_area.grid(row=3, column=0, columnspan=3)

        # Initialize the data variable
        self.data = None

        # Create frames for the Digital Olympics functionality
        self.create_olympics_interface()

    # This method is called when the user presses the "Download" button
    def download_document(self):
        url = self.url_input.get()
        if url:
            self.progress.start()  # Start the progress bar
            self.master.update()  # Update the UI

            # Download the document
            self.data = download(url)
            if self.data is None:
                messagebox.showerror("Download Error", "Failed to download the document.")
            else:
                messagebox.showinfo("Download Complete", "Document downloaded successfully.")
            self.progress.stop()  # Stop the progress bar

    # This method displays the downloaded data in the text area
    def display_data(self):
        if self.data:
            self.text_area.delete(1.0, END)  # Clear previous text
            self.text_area.insert(END, self.data)  # Insert new data
        else:
            messagebox.showwarning("No Data", "No data available to display. Please download a document first.")

    def create_olympics_interface(self):
        # Create frames for organization
        olympics_frame = tk.Frame(self.master)
        olympics_frame.grid(row=4, column=0, columnspan=3, pady=10)

        # Trophy podium style (all trophies on the same base level)
        trophy_frame = tk.Frame(olympics_frame)
        trophy_frame.grid(row=0, column=0, columnspan=3, pady=10)

        # Podium arrangement for trophies (remove padding between them)
        silver_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 50), fg="silver")
        silver_label.grid(row=1, column=0, sticky="s")  # Left, aligned at bottom

        gold_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 70), fg="gold")
        gold_label.grid(row=0, column=1, rowspan=2, sticky="s")  # Center, aligned at bottom

        bronze_label = tk.Label(trophy_frame, text="🏆", font=("Arial", 50), fg="brown")
        bronze_label.grid(row=1, column=2, sticky="s")  # Right, aligned at bottom

        # Remove padding between the trophies
        trophy_frame.grid_columnconfigure(0, minsize=0)
        trophy_frame.grid_columnconfigure(1, minsize=0)
        trophy_frame.grid_columnconfigure(2, minsize=0)

        # Numbers for podium (display the positions below the trophies)
        silver_position = tk.Label(trophy_frame, text="2", font=("Arial", 30), fg="gray")
        silver_position.grid(row=2, column=0, padx=0, pady=(0, 10))

        gold_position = tk.Label(trophy_frame, text="1", font=("Arial", 30), fg="gold")
        gold_position.grid(row=2, column=1, padx=0, pady=(0, 10))

        bronze_position = tk.Label(trophy_frame, text="3", font=("Arial", 30), fg="brown")
        bronze_position.grid(row=2, column=2, padx=0, pady=(0, 10))

        # Frame for rankings and save winner options
        ranking_winner_frame = tk.Frame(olympics_frame)
        ranking_winner_frame.grid(row=1, column=0, columnspan=2, pady=10)

        # Choose and view ranking section
        ranking_frame = tk.Frame(ranking_winner_frame)
        ranking_frame.grid(row=0, column=0, padx=20)

        ranking_var = tk.StringVar(value="Most-Pirated Online Movies")
        ranking_options = [
            ("Top-Rating iTunes TV Episodes", "Top-Rating iTunes TV Episodes"),
            ("Most-Pirated Online Movies", "Most-Pirated Online Movies"),
            ("Top-Selling Pop Songs in the UK", "Top-Selling Pop Songs in the UK")
        ]

        ranking_label = tk.Label(ranking_frame, text="Choose and view a ranking:")
        ranking_label.pack(anchor="w", pady=5)

        for text, value in ranking_options:
            tk.Radiobutton(ranking_frame, text=text, variable=ranking_var, value=value).pack(anchor="w")

        # Buttons for showing top three and data source in one row
        button_frame = tk.Frame(ranking_frame)
        button_frame.pack(pady=5)

        tk.Button(button_frame, text="Show top three", command=show_top_three).pack(side="left", padx=10)
        tk.Button(button_frame, text="Show data source", command=show_data_source).pack(side="left", padx=10)

        # Save a winner section
        save_winner_frame = tk.Frame(ranking_winner_frame)
        save_winner_frame.grid(row=0, column=1, padx=20)

        save_winner_label = tk.Label(save_winner_frame, text="Save a winner:")
        save_winner_label.pack(anchor="w", pady=5)

        tk.Button(save_winner_frame, text="Gold", command=lambda: save_winner("Gold")).pack(side="top", pady=2)
        tk.Button(save_winner_frame, text="Silver", command=lambda: save_winner("Silver")).pack(side="top", pady=2)
        tk.Button(save_winner_frame, text="Bronze", command=lambda: save_winner("Bronze")).pack(side="top", pady=2)

        # Messages and status section
        messages_frame = tk.Frame(olympics_frame)
        messages_frame.grid(row=2, column=0, columnspan=2, pady=10)

        global messages_label  # Make it accessible to other functions
        messages_label = tk.Label(messages_frame, text="Most-Pirated Online Movies (title and IMDb rating):", justify="left")
        messages_label.pack(anchor="w", pady=5)

        global status_label  # Make it accessible to other functions
        status_label = tk.Label(root, text="Status: Ready", fg="blue")
        status_label.pack(pady=5)

# Main Code Execution
if __name__ == "__main__":
    root = tk.Tk()
    app = OnlineDataViewer(root)
    root.mainloop()
