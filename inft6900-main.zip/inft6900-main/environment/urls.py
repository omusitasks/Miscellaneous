# urls.py
from django.urls import path
from .views import (
    KilometresTravelledUploadView, 
    GreenhouseGasEmissionsBySectorUploadView, 
    GreenhouseGasEmissionsByTransportUploadView, 
    GreenhouseGasEmissionsBySuburbUploadView,
    EmissionsVisualizationView
)


urlpatterns = [
    # api to upload dataset one
    path('upload/kilometres-travelled/', KilometresTravelledUploadView.as_view(), name='upload-kilometres-travelled'),
    # api to upload dataset two
    path('upload/ghg-by-sector/', GreenhouseGasEmissionsBySectorUploadView.as_view(), name='upload-ghg-by-sector'),
    # api to upload dataset three
    path('upload/ghg-by-transport/', GreenhouseGasEmissionsByTransportUploadView.as_view(), name='upload-ghg-by-transport'),
    # api to upload dataset four
    path('upload/ghg-by-suburb/', GreenhouseGasEmissionsBySuburbUploadView.as_view(), name='upload-ghg-by-suburb'),

    # api to display visualizations from the cleaned dataset stored in the database
    path('visualizations/emissions/', EmissionsVisualizationView.as_view(), name='emissions_visualization')
]

