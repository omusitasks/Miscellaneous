from django.db import models

# Dataset one
# Model for Kilometres Travelled by Mode of Transport
class KilometresTravelled(models.Model):
    data_type = models.CharField(max_length=255)
    f2005_06 = models.FloatField()
    f2006_07 = models.FloatField()
    f2007_08 = models.FloatField()
    f2008_09 = models.FloatField()
    f2009_10 = models.FloatField()
    f2010_11 = models.FloatField()
    f2011_12 = models.FloatField()
    f2012_13 = models.FloatField()
    f2013_14 = models.FloatField()
    f2014_15 = models.FloatField()
    f2015_16 = models.FloatField()
    f2016_17 = models.FloatField()
    f2017_18 = models.FloatField()
    f2018_19 = models.FloatField()
    object_id = models.IntegerField()


# For dataset two
# Model for Greenhouse Gas Emissions by Sector
class GreenhouseGasEmissionsBySector(models.Model):
    custom_grouping = models.CharField(max_length=255)
    sector_level_2 = models.CharField(max_length=255)
    fid = models.IntegerField()
    f2005_06 = models.FloatField()
    f2006_07 = models.FloatField()
    f2007_08 = models.FloatField()
    f2008_09 = models.FloatField()
    f2009_10 = models.FloatField()
    f2010_11 = models.FloatField()
    f2011_12 = models.FloatField()
    f2012_13 = models.FloatField()
    f2013_14 = models.FloatField()
    f2014_15 = models.FloatField()
    f2015_16 = models.FloatField()
    f2016_17 = models.FloatField()
    f2017_18 = models.FloatField()
    f2018_19 = models.FloatField()


# for dataset three
# Model for Greenhouse Gas Emissions by Modes of Transport
class GreenhouseGasEmissionsByTransport(models.Model):
    data_category = models.CharField(max_length=255)
    data_type = models.CharField(max_length=255)
    f2005_06 = models.FloatField()
    f2006_07 = models.FloatField()
    f2007_08 = models.FloatField()
    f2008_09 = models.FloatField()
    f2009_10 = models.FloatField()
    f2010_11 = models.FloatField()
    f2011_12 = models.FloatField()
    f2012_13 = models.FloatField()
    f2013_14 = models.FloatField()
    f2014_15 = models.FloatField()
    f2015_16 = models.FloatField()
    f2016_17 = models.FloatField()
    f2017_18 = models.FloatField()
    f2018_19 = models.FloatField()
    object_id = models.IntegerField()


# for dataset four
# Model for Greenhouse Gas Emissions Profile by Suburb
class GreenhouseGasEmissionsBySuburb(models.Model):
    objectid1 = models.IntegerField()
    area_suburb = models.CharField(max_length=255)
    data_category = models.CharField(max_length=255)
    f2005_06 = models.FloatField()
    f2006_07 = models.FloatField()
    f2007_08 = models.FloatField()
    f2008_09 = models.FloatField()
    f2009_10 = models.FloatField()
    f2010_11 = models.FloatField()
    f2011_12 = models.FloatField()
    f2012_13 = models.FloatField()
    f2013_14 = models.FloatField()
    f2014_15 = models.FloatField()
    f2015_16 = models.FloatField()
    f2016_17 = models.FloatField()
    f2017_18 = models.FloatField()
    f2018_19 = models.FloatField()
    shape_area = models.FloatField()
    shape_length = models.FloatField()
    
