# serializers.PY

from rest_framework import serializers
from .models import (
    KilometresTravelled, 
    GreenhouseGasEmissionsBySector, 
    GreenhouseGasEmissionsByTransport, 
    GreenhouseGasEmissionsBySuburb
)

class KilometresTravelledSerializer(serializers.ModelSerializer):
    class Meta:
        model = KilometresTravelled
        fields = '__all__'

class GreenhouseGasEmissionsBySectorSerializer(serializers.ModelSerializer):
    class Meta:
        model = GreenhouseGasEmissionsBySector
        fields = '__all__'

class GreenhouseGasEmissionsByTransportSerializer(serializers.ModelSerializer):
    class Meta:
        model = GreenhouseGasEmissionsByTransport
        fields = '__all__'


class GreenhouseGasEmissionsBySuburbSerializer(serializers.ModelSerializer):
    class Meta:
        model = GreenhouseGasEmissionsBySuburb
        fields = '__all__'



