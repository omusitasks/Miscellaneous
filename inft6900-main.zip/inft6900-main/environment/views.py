import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from rest_framework.response import Response
from rest_framework import status, views
from .models import (
    KilometresTravelled, 
    GreenhouseGasEmissionsBySector, 
    GreenhouseGasEmissionsByTransport, 
    GreenhouseGasEmissionsBySuburb
)
from .serializers import (
    KilometresTravelledSerializer, 
    GreenhouseGasEmissionsBySectorSerializer, 
    GreenhouseGasEmissionsByTransportSerializer, 
    GreenhouseGasEmissionsBySuburbSerializer
)
from rest_framework.views import APIView
import os
from io import BytesIO
from django.http import HttpResponse
import geopandas as gpd  # For geographic data plotting
import random
from rest_framework import views



# Helper function for CSV data processing
import logging  # to log errors

# Setup logging if not already done
logger = logging.getLogger(__name__)

"""
#  function to perform data preprocessing steps:namely
  -  upload the 4 datasets
  - clean the datasets (entails, working on missing values, data connvertion for consistent, working on duplicates values etc)
  - after the data is preprocessed  the data is saved in db as clean data
  - this fucntion also ensures that user does not enter duplicate records in the database
"""

def process_csv(file, model, serializer_class):
    try:
        df = pd.read_csv(file)

        # Dynamically map the columns based on the model
        if model == KilometresTravelled:
            df.columns = [
                'data_type', 'f2005_06', 'f2006_07', 'f2007_08', 'f2008_09', 
                'f2009_10', 'f2010_11', 'f2011_12', 'f2012_13', 'f2013_14', 
                'f2014_15', 'f2015_16', 'f2016_17', 'f2017_18', 'f2018_19', 
                'object_id'
            ]
            df['data_type'] = df['data_type'].astype(str)
            numeric_columns = df.columns.difference(['data_type'])

        elif model == GreenhouseGasEmissionsBySector:
            df.columns = [
                'custom_grouping', 'sector_level_2', 'fid', 'f2005_06', 
                'f2006_07', 'f2007_08', 'f2008_09', 'f2009_10', 'f2010_11', 
                'f2011_12', 'f2012_13', 'f2013_14', 'f2014_15', 'f2015_16', 
                'f2016_17', 'f2017_18', 'f2018_19'
            ]
            df['custom_grouping'] = df['custom_grouping'].astype(str)
            df['sector_level_2'] = df['sector_level_2'].astype(str)
            numeric_columns = df.columns.difference(['custom_grouping', 'sector_level_2', 'fid'])

        elif model == GreenhouseGasEmissionsByTransport:
            df.columns = [
                'data_category', 'data_type', 'f2005_06', 'f2006_07', 'f2007_08', 
                'f2008_09', 'f2009_10', 'f2010_11', 'f2011_12', 'f2012_13', 
                'f2013_14', 'f2014_15', 'f2015_16', 'f2016_17', 'f2017_18', 
                'f2018_19', 'object_id'
            ]
            df['data_category'] = df['data_category'].astype(str)
            df['data_type'] = df['data_type'].astype(str)
            numeric_columns = df.columns.difference(['data_category', 'data_type'])

        elif model == GreenhouseGasEmissionsBySuburb:
            df.columns = [
                'objectid1', 'area_suburb', 'data_category', 'f2005_06', 'f2006_07', 'f2007_08', 
                'f2008_09', 'f2009_10', 'f2010_11', 'f2011_12', 'f2012_13', 'f2013_14', 'f2014_15', 
                'f2015_16', 'f2016_17', 'f2017_18', 'f2018_19', 'Shape__Area', 'Shape__Length'
            ]
            df.rename(columns={'Shape__Area': 'shape_area', 'Shape__Length': 'shape_length'}, inplace=True)

            # Set data types for columns
            df['area_suburb'] = df['area_suburb'].astype(str)
            df['data_category'] = df['data_category'].astype(str)
            numeric_columns = df.columns.difference(['area_suburb', 'data_category'])

        else:
            raise ValueError("Unrecognized model passed to the process_csv function.")

        # Convert numeric columns only
        df[numeric_columns] = df[numeric_columns].replace(r'[^0-9.]', '', regex=True)  # Clean numeric columns
        df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric, errors='coerce')  # Convert cleaned data to numeric

        # Replace NaN values in numeric columns with the column's mean
        for col in numeric_columns:
            mean_value = df[col].mean()
            df[col].fillna(mean_value, inplace=True)

        # Check for any remaining NaN values
        if df[numeric_columns].isnull().values.any():
            logger.error("NaN values found after processing: %s", df[numeric_columns].isnull().sum())
            return {"status": "error", "message": "Data contains NaN values that cannot be processed."}

        # Keep track of whether duplicates were found
        duplicates_found = False

        # Check for duplicates in the database
        for _, row in df.iterrows():
            data = row.to_dict()

            # Check for existing records by unique fields
            if model == KilometresTravelled:
                existing_record = model.objects.filter(object_id=data['object_id']).first()
            elif model == GreenhouseGasEmissionsBySector:
                existing_record = model.objects.filter(fid=data['fid']).first()
            elif model == GreenhouseGasEmissionsByTransport:
                existing_record = model.objects.filter(object_id=data['object_id']).first()
            elif model == GreenhouseGasEmissionsBySuburb:
                existing_record = model.objects.filter(objectid1=data['objectid1']).first()

            # Skip if record already exists
            if existing_record:
                logger.info(f"Skipping duplicate record: {data}")
                duplicates_found = True
                continue

            # If not a duplicate, serialize and save
            serializer = serializer_class(data=data)
            if serializer.is_valid():
                serializer.save()
            else:
                logger.error("Serializer error: %s", serializer.errors)
                return {"status": "error", "message": "Error with data serialization."}

        # Return result based on whether duplicates were found
        if duplicates_found:
            return {"status": "duplicates", "message": "You have already inserted similar records, thus duplicates were skipped."}
        else:
            return {"status": "success", "message": "Data uploaded successfully!"}

    except pd.errors.ParserError as e:
        logger.error("CSV Parsing error: %s", str(e))
        return {"status": "error", "message": "Error parsing the CSV file."}

    except Exception as e:
        logger.error("Error during CSV processing: %s", str(e))
        return {"status": "error", "message": "An internal error occurred."}

#  from here are the apis to upload the 4 datasets
# Kilometres Travelled Upload View
class KilometresTravelledUploadView(APIView):
    def post(self, request, *args, **kwargs):
        file = request.FILES['file']
        result = process_csv(file, KilometresTravelled, KilometresTravelledSerializer)

        if result['status'] == 'success':
            return Response({"message": result['message']}, status=status.HTTP_201_CREATED)
        elif result['status'] == 'duplicates':
            return Response({"message": result['message']}, status=status.HTTP_200_OK)
        else:
            return Response({"message": result['message']}, status=status.HTTP_400_BAD_REQUEST)


# Greenhouse Gas Emissions by Sector Upload View
class GreenhouseGasEmissionsBySectorUploadView(APIView):
    def post(self, request, *args, **kwargs):
        file = request.FILES['file']
        result = process_csv(file, GreenhouseGasEmissionsBySector, GreenhouseGasEmissionsBySectorSerializer)

        if result['status'] == 'success':
            return Response({"message": result['message']}, status=status.HTTP_201_CREATED)
        elif result['status'] == 'duplicates':
            return Response({"message": result['message']}, status=status.HTTP_200_OK)
        else:
            return Response({"message": result['message']}, status=status.HTTP_400_BAD_REQUEST)


# Greenhouse Gas Emissions by Transport Upload View
class GreenhouseGasEmissionsByTransportUploadView(APIView):
    def post(self, request, *args, **kwargs):
        file = request.FILES['file']
        result = process_csv(file, GreenhouseGasEmissionsByTransport, GreenhouseGasEmissionsByTransportSerializer)

        if result['status'] == 'success':
            return Response({"message": result['message']}, status=status.HTTP_201_CREATED)
        elif result['status'] == 'duplicates':
            return Response({"message": result['message']}, status=status.HTTP_200_OK)
        else:
            return Response({"message": result['message']}, status=status.HTTP_400_BAD_REQUEST)



# Greenhouse Gas Emissions Profile by Suburb Upload View
class GreenhouseGasEmissionsBySuburbUploadView(APIView):
    def post(self, request, *args, **kwargs):
        file = request.FILES['file']
        result = process_csv(file, GreenhouseGasEmissionsBySuburb, GreenhouseGasEmissionsBySuburbSerializer)

        if result['status'] == 'success':
            return Response({"message": result['message']}, status=status.HTTP_201_CREATED)
        elif result['status'] == 'duplicates':
            return Response({"message": result['message']}, status=status.HTTP_200_OK)
        else:
            return Response({"message": result['message']}, status=status.HTTP_400_BAD_REQUEST)


"""
#  then finally visualization of the dataset 
- achieved by combining the fours dataset on the basis of the research objective
"""

# API FOR DATA VISUALIZATION
# Data visualization API

#  return HttpResponse(buf.getvalue(), content_type='image/png')
class EmissionsVisualizationView(views.APIView):
    def get(self, request, *args, **kwargs):
        # Step 1: Combine the Datasets
        km_data = pd.DataFrame(list(KilometresTravelled.objects.all().values()))
        ghg_sector_data = pd.DataFrame(list(GreenhouseGasEmissionsBySector.objects.all().values()))
        ghg_transport_data = pd.DataFrame(list(GreenhouseGasEmissionsByTransport.objects.all().values()))
        ghg_suburb_data = pd.DataFrame(list(GreenhouseGasEmissionsBySuburb.objects.all().values()))

        # Rename columns to prevent duplicates
        km_data.rename(columns={col: f'km_{col}' for col in km_data.columns}, inplace=True)
        ghg_sector_data.rename(columns={col: f'sector_{col}' for col in ghg_sector_data.columns}, inplace=True)
        ghg_transport_data.rename(columns={col: f'transport_{col}' for col in ghg_transport_data.columns}, inplace=True)
        ghg_suburb_data.rename(columns={col: f'suburb_{col}' for col in ghg_suburb_data.columns}, inplace=True)

        # Merge datasets on common keys
        combined_data = km_data.merge(ghg_sector_data, left_on='km_object_id', right_on='sector_fid', how='outer')
        combined_data = combined_data.merge(ghg_transport_data, left_on='km_object_id', right_on='transport_object_id', how='outer')
        combined_data = combined_data.merge(ghg_suburb_data, left_on='km_object_id', right_on='suburb_objectid1', how='outer')

        # Fill NaN values with 0 or appropriate values
        combined_data.fillna(0, inplace=True)

        # Step 2: Create a grid for multiple visualizations
        fig, axes = plt.subplots(4, 2, figsize=(20, 18))  # Increased figure size

        # 1. Bar chart: Greenhouse Gas Emissions by Transport Mode in 2018/19
        sns.barplot(data=combined_data, x='transport_data_category', y='sector_f2018_19', ax=axes[0, 0])
        axes[0, 0].set_title('GHG Emissions by Transport Mode (2018/19)')
        axes[0, 0].set_xlabel('Transport Mode')
        axes[0, 0].set_ylabel('Emissions')
        axes[0, 0].tick_params(axis='x', rotation=45)

        # 2. Line chart: GHG Emissions over Time (for each transport mode)
        combined_data.set_index('km_object_id').filter(like='f20', axis=1).T.plot(ax=axes[0, 1])
        axes[0, 1].set_title('GHG Emissions Trends Over Time')
        axes[0, 1].set_xlabel('Year')
        axes[0, 1].set_ylabel('Emissions')

        # 3. Pie chart: Proportion of Emissions by Transport Mode (2018/19)
        transport_emissions = combined_data.groupby('transport_data_category')['sector_f2018_19'].sum()
        axes[1, 0].pie(transport_emissions, labels=transport_emissions.index, autopct='%1.1f%%', startangle=140)
        axes[1, 0].set_title('Proportion of Emissions by Transport Mode (2018/19)')

        # 4. Heatmap: Correlation between Transportation Modes and Emissions
        corr_matrix = combined_data.filter(like='f20', axis=1).corr()
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', ax=axes[1, 1])
        axes[1, 1].set_title('Correlation between Years of Emissions Data')

        # 5. Choropleth Map: Greenhouse Gas Emissions by Suburb
        gdf = gpd.GeoDataFrame(ghg_suburb_data, geometry=gpd.points_from_xy([random.random() for _ in range(len(ghg_suburb_data))], [random.random() for _ in range(len(ghg_suburb_data))]))
        gdf.plot(column='suburb_f2018_19', cmap='OrRd', legend=True, ax=axes[2, 0])
        axes[2, 0].set_title('GHG Emissions by Suburb in 2018/19')

        # 6. Scatter plot: Kilometres Travelled vs. GHG Emissions
        sns.scatterplot(data=combined_data, x='km_f2018_19', y='sector_f2018_19', ax=axes[2, 1])
        axes[2, 1].set_title('Kilometres Travelled vs. GHG Emissions (2018/19)')
        axes[2, 1].set_xlabel('Kilometres Travelled in 2018/19')
        axes[2, 1].set_ylabel('GHG Emissions in 2018/19')

        # 7. Box plot: Emissions distribution by Transport Mode
        sns.boxplot(data=combined_data, x='transport_data_category', y='sector_f2018_19', ax=axes[3, 0])
        axes[3, 0].set_title('Emissions Distribution by Transport Mode')
        axes[3, 0].set_xlabel('Transport Mode')
        axes[3, 0].set_ylabel('Emissions')
        axes[3, 0].tick_params(axis='x', rotation=45)

        # Remove the last empty subplot (since we only need 7 plots)
        fig.delaxes(axes[3, 1])

        # Adjust layout to prevent overlap
        plt.subplots_adjust(hspace=0.4, wspace=0.3)

        plt.tight_layout()

        # Save the grid of plots to a BytesIO object
        buf = BytesIO()
        plt.savefig(buf, format='png')
        plt.close()
        buf.seek(0)

        return HttpResponse(buf.getvalue(), content_type='image/png')
