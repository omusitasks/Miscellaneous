# from dagshub.streaming import DagsHubFilesystem

# fs = DagsHubFilesystem(".", repo_url="https://dagshub.com/DagsHub-Datasets/amazon-last-mile-challenges-dataset")

# fs.listdir("s3://amazon-last-mile-challenges")

import numpy as np
import matplotlib.pyplot as plt

# Example: Stairs data (non-destructive measurements)
steps = 10  # Number of steps
wear_depth = np.array([1.2, 1.5, 1.7, 2.0, 2.3, 2.5, 2.6, 2.8, 3.0, 3.2])  # Measured wear depth (cm)
step_width = np.array([100, 100, 100, 100, 100, 100, 100, 100, 100, 100])  # Step width (cm)
material_hardness = 7  # Material hardness (e.g., Mohs scale)

# Model: Estimate usage frequency based on wear depth
usage_rate = wear_depth / (material_hardness * 0.01)  # Simplified model (people/day)
total_usage = np.sum(usage_rate)  # Total usage across all steps

# Directionality analysis
left_wear = wear_depth * 0.6  # Assume 60% wear on the left side
right_wear = wear_depth * 0.4  # Assume 40% wear on the right side
direction_bias = np.sum(left_wear) / np.sum(right_wear)

# Simultaneous usage (based on worn width)
worn_width = step_width * (wear_depth / np.max(wear_depth))  # Worn width estimate
single_file = np.all(worn_width < 50)  # Assume single-file if width < 50 cm

# Visualize wear depth
plt.figure(figsize=(8, 5))
plt.bar(range(1, steps + 1), wear_depth, color='blue', alpha=0.7, label='Wear Depth (cm)')
plt.xlabel("Step Number")
plt.ylabel("Wear Depth (cm)")
plt.title("Wear Depth Across Stairs")
plt.legend()
plt.show()

# Results
print("Estimated Usage Rate (people/day):", usage_rate)
print("Total Usage Over Time (approx):", total_usage)
print("Direction Bias (Left/Right):", direction_bias)
print("Simultaneous Usage (Single File):", single_file)
