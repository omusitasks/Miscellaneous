# Load necessary libraries
library(shiny)
library(ggplot2)
library(dplyr)

# Define the new dataset directly
data <- read.csv("1280649694_9711730180782.csv")

# Define UI for the application
ui <- fluidPage(
  sidebarLayout(
    sidebarPanel(
      checkboxGroupInput("categories", "Categories:", 
                         choices = list("HIGH_HAND", "HIGH_LEG", "LOW_HAND", "LOW_LEG"),
                         selected = c("HIGH_HAND", "HIGH_LEG", "LOW_HAND", "LOW_LEG")),
      sliderInput("experiment_id", "Experiment ID:",
                  min = min(data$Experiment_ID), max = max(data$Experiment_ID),
                  value = c(min(data$Experiment_ID), max(data$Experiment_ID))),
      sliderInput("range_high_hand", "Range HIGH_HAND:",
                  min = min(data$HIGH_HAND), max = max(data$HIGH_HAND),
                  value = c(min(data$HIGH_HAND), max(data$HIGH_HAND))),
      sliderInput("range_high_leg", "Range HIGH_LEG:",
                  min = min(data$HIGH_LEG), max = max(data$HIGH_LEG),
                  value = c(min(data$HIGH_LEG), max(data$HIGH_LEG))),
      sliderInput("range_low_hand", "Range LOW_HAND:",
                  min = min(data$LOW_HAND), max = max(data$LOW_HAND),
                  value = c(min(data$LOW_HAND), max(data$LOW_HAND))),
      sliderInput("range_low_leg", "Range LOW_LEG:",
                  min = min(data$LOW_LEG), max = max(data$LOW_LEG),
                  value = c(min(data$LOW_LEG), max(data$LOW_LEG))
      )
    ),
    
    mainPanel(
      plotOutput("boxPlot"),
      tableOutput("summaryTable")
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  # Filter data based on input selections
  filtered_data <- reactive({
    data %>%
      filter(
        HIGH_HAND >= input$range_high_hand[1] & HIGH_HAND <= input$range_high_hand[2],
        HIGH_LEG >= input$range_high_leg[1] & HIGH_LEG <= input$range_high_leg[2],
        LOW_HAND >= input$range_low_hand[1] & LOW_HAND <= input$range_low_hand[2],
        LOW_LEG >= input$range_low_leg[1] & LOW_LEG <= input$range_low_leg[2],
        Experiment_ID >= input$experiment_id[1] & Experiment_ID <= input$experiment_id[2]
      )
  })
  
  # Render boxplot
  output$boxPlot <- renderPlot({
    plot_data <- filtered_data()
    
    # Prepare data for plotting
    plot_data <- plot_data %>%
      pivot_longer(cols = c(HIGH_HAND, HIGH_LEG, LOW_HAND, LOW_LEG), 
                   names_to = "Category", values_to = "Value") %>%
      filter(Category %in% input$categories)
    
    ggplot(plot_data, aes(x = Category, y = Value)) +
      geom_boxplot(aes(fill = Category)) +
      scale_fill_manual(values = c("HIGH_HAND" = "#FF9999", "HIGH_LEG" = "#99CC99", 
                                   "LOW_HAND" = "#66CCCC", "LOW_LEG" = "#CC99FF")) +
      theme_minimal() +
      theme(panel.background = element_blank(),
            panel.grid = element_blank(),
            legend.position = "none") +
      labs(title = "Boxplot per Categories") +
      xlab("Category") +  # Label for x-axis
      ylab("Value")       # Label for y-axis
  })
  
  # Render summary table
  output$summaryTable <- renderTable({
    summary_data <- filtered_data() %>%
      pivot_longer(cols = c(HIGH_HAND, HIGH_LEG, LOW_HAND, LOW_LEG), 
                   names_to = "Category", values_to = "Value") %>%
      filter(Category %in% input$categories) %>%
      group_by(Category) %>%
      summarise(
        Average = round(mean(Value, na.rm = TRUE), 2),
        STD = round(sd(Value, na.rm = TRUE), 2)
      )
    summary_data
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
