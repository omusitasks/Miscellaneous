# Part (a): Data Preparation in R

# Load necessary libraries
library(dplyr)

# Load the dataset
data <- read.csv("1737661880_8411730180701.csv")

# Define colors based on the target variable
data$color <- ifelse(data$target == 0, "red",
                     ifelse(data$target == 1, "green", "blue"))

# Set the point size
data$size <- 0.2

# Save the cleaned data to a new CSV file for A-Frame
write.csv(data, "cleaned_dataset_aframe.csv", row.names = FALSE)

# Display the cleaned data (optional)
print(head(data))
