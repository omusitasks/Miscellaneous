# Load necessary libraries
library(ggplot2)
library(dplyr)
library(tidyr)

# Create the dataset embedded within the code
data <- data.frame(
  Month = c("Jan-19", "Feb-19", "Mar-19", "Apr-19", "May-19", "Jun-19",
            "Jul-19", "Aug-19", "Sep-19", "Oct-19", "Nov-19", "Dec-19"),
  Direct_Sales = c(82.2, 76.9, 85.7, 78.1, 88.1, 79.6, 83.4, 79.5, 82.6, 80.2, 81.1, 66.8),
  Indirect_Sales = c(47, 58.2, 62.4, 55.9, 72.0, 60.3, 50.8, 69.9, 59.3, 60.7, 68.8, 46.8)
)

# Define the goal threshold
goal_threshold <- 90

# Reshape data for ggplot2 using gather()
data_long <- data %>%
  gather(key = "Sales_Type", value = "Days_to_Close", -Month)

# Ensure the Month variable is ordered from Jan to Dec
data_long$Month <- factor(data_long$Month, levels = c("Jan-19", "Feb-19", "Mar-19", "Apr-19", "May-19", "Jun-19",
                                                      "Jul-19", "Aug-19", "Sep-19", "Oct-19", "Nov-19", "Dec-19"))

# Modify the Y-axis scale to have intervals of 20
plot <- ggplot(data_long, aes(x = Month, y = Days_to_Close, fill = Sales_Type)) +
  geom_bar(stat = "identity", position = "dodge", color = "black") +
  scale_fill_manual(values = c("Direct_Sales" = "green", "Indirect_Sales" = "blue")) +
  
  # Highlight bars that exceed the goal threshold
  geom_bar(data = subset(data_long, Days_to_Close > goal_threshold),
           aes(x = Month, y = Days_to_Close, fill = Sales_Type),
           stat = "identity", position = "dodge", color = "black", alpha = 0.8) +
  scale_fill_manual(values = c("Direct_Sales" = "green", "Indirect_Sales" = "blue", "Above Goal" = "red")) +
  
  # Add the goal line
  geom_hline(yintercept = goal_threshold, linetype = "dashed", color = "red", size = 1) +
  
  # Title and subtitles
  labs(title = "Time to Close Deal", subtitle = "Goal = 90 Days",
       x = NULL, y = "Days to Close") +
  
  # Set Y-axis scale intervals to 20
  scale_y_continuous(breaks = seq(0, 140, by = 20)) +
  
  # Theme adjustments for clarity
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.y = element_text(size = 12),
    legend.position = "bottom",
    legend.title = element_blank(),
    legend.text = element_text(size = 10)
  ) +
  
  # Add annotation as takeaway information
  annotate("text", x = 6.5, y = 130, label = "Goal exceeded in Apr, Jul, and Sep 2019", color = "red", size = 4)

# Print the plot
print(plot)
