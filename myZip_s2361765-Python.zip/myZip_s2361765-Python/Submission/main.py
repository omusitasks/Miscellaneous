import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from scipy.optimize import minimize
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

# Function to read and prepare data
def prepare_data(excel_file, sheet_name=0):
    """
    Read in the Excel file and prepare the data.
    Returns industry portfolios and Fama-French factors dataframes.
    """
    # Read the industry portfolios
    industry_portfolios = pd.read_excel(excel_file, sheet_name=sheet_name, index_col='Month')
    
    # Assuming Fama-French factors are in another sheet, adjust as needed
    try:
        ff_factors = pd.read_excel(excel_file, sheet_name='FF_Factors', index_col='Month')
    except:
        print("Fama-French factors sheet not found. Proceeding with industry portfolios only.")
        ff_factors = None
    
    # Convert index to datetime if it's not already
    if not isinstance(industry_portfolios.index, pd.DatetimeIndex):
        industry_portfolios.index = pd.to_datetime(industry_portfolios.index, format='%Y%m')
    
    if ff_factors is not None and not isinstance(ff_factors.index, pd.DatetimeIndex):
        ff_factors.index = pd.to_datetime(ff_factors.index, format='%Y%m')
    
    return industry_portfolios, ff_factors

# Function to calculate portfolio statistics
def calculate_portfolio_stats(returns, weights):
    """
    Calculate portfolio expected return, volatility, and Sharpe ratio.
    """
    portfolio_return = np.sum(returns.mean() * weights) * 12  # Annualized return
    portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(returns.cov() * 12, weights)))  # Annualized volatility
    return portfolio_return, portfolio_volatility

# Function to calculate Sharpe ratio
def calculate_sharpe_ratio(returns, weights, risk_free_rate):
    """
    Calculate the Sharpe ratio of a portfolio.
    """
    portfolio_return, portfolio_volatility = calculate_portfolio_stats(returns, weights)
    sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_volatility
    return sharpe_ratio

# Function to find minimum variance portfolio
def minimum_variance_portfolio(returns):
    """
    Find the minimum variance portfolio weights.
    """
    n = returns.shape[1]
    args = (returns.cov())
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bounds = tuple((0, 1) for asset in range(n))
    
    def portfolio_volatility(weights, cov_matrix):
        return np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    
    initial_guess = np.array([1/n for _ in range(n)])
    result = minimize(portfolio_volatility, initial_guess, args=args, method='SLSQP', bounds=bounds, constraints=constraints)
    
    return result['x']

# Function to generate efficient frontier
def efficient_frontier(returns, risk_free_rate, num_portfolios=100):
    """
    Generate the efficient frontier for a set of assets.
    Includes the risk-free asset for the capital allocation line.
    """
    n = returns.shape[1]
    
    # Getting the covariance matrix
    cov_matrix = returns.cov()
    
    # Function to minimize negative Sharpe Ratio
    def neg_sharpe_ratio(weights):
        portfolio_return = np.sum(returns.mean() * weights) * 12
        portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(cov_matrix * 12, weights)))
        sharpe = (portfolio_return - risk_free_rate) / portfolio_volatility
        return -sharpe
    
    # Constraints and bounds
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bounds = tuple((0, 1) for asset in range(n))
    
    # Initial guess
    initial_guess = np.array([1/n for _ in range(n)])
    
    # Find the optimal portfolio (tangency portfolio)
    result = minimize(neg_sharpe_ratio, initial_guess, method='SLSQP', bounds=bounds, constraints=constraints)
    optimal_weights = result['x']
    
    # Get optimal portfolio stats
    optimal_return, optimal_volatility = calculate_portfolio_stats(returns, optimal_weights)
    optimal_sharpe = (optimal_return - risk_free_rate) / optimal_volatility
    
    # Find minimum variance portfolio
    min_var_weights = minimum_variance_portfolio(returns)
    min_var_return, min_var_volatility = calculate_portfolio_stats(returns, min_var_weights)
    
    # Generate random portfolios for visualization
    means, stds = np.zeros(num_portfolios), np.zeros(num_portfolios)
    weights_array = np.zeros((num_portfolios, n))
    
    for i in range(num_portfolios):
        # Generate random weights
        weights = np.random.random(n)
        weights = weights / np.sum(weights)
        weights_array[i, :] = weights
        
        # Calculate portfolio stats
        portfolio_return, portfolio_volatility = calculate_portfolio_stats(returns, weights)
        means[i] = portfolio_return
        stds[i] = portfolio_volatility
    
    # Calculate the Capital Allocation Line (CAL)
    cal_x = np.linspace(0, max(stds) * 1.5, 100)
    cal_y = risk_free_rate + optimal_sharpe * cal_x
    
    return {
        'returns': means,
        'volatilities': stds,
        'weights': weights_array,
        'optimal_weights': optimal_weights,
        'optimal_return': optimal_return,
        'optimal_volatility': optimal_volatility,
        'optimal_sharpe': optimal_sharpe,
        'min_var_weights': min_var_weights,
        'min_var_return': min_var_return,
        'min_var_volatility': min_var_volatility,
        'cal_x': cal_x,
        'cal_y': cal_y,
        'risk_free_rate': risk_free_rate
    }

# Function to plot efficient frontier
def plot_efficient_frontier(ef_results, title, asset_names=None):
    """
    Plot the efficient frontier.
    """
    plt.figure(figsize=(12, 8))
    
    # Plot random portfolios
    plt.scatter(ef_results['volatilities'], ef_results['returns'], 
                c=ef_results['returns']/ef_results['volatilities'], cmap='viridis', marker='o', s=10, alpha=0.3)
    
    # Plot optimal portfolio
    plt.scatter(ef_results['optimal_volatility'], ef_results['optimal_return'], 
                marker='*', color='r', s=300, label='Tangency Portfolio')
    
    # Plot minimum variance portfolio
    plt.scatter(ef_results['min_var_volatility'], ef_results['min_var_return'], 
                marker='P', color='g', s=200, label='Minimum Variance Portfolio')
    
    # Plot Capital Allocation Line
    plt.plot(ef_results['cal_x'], ef_results['cal_y'], 'k--', label='Capital Allocation Line')
    
    # Plot risk-free rate
    plt.scatter(0, ef_results['risk_free_rate'], marker='o', color='k', s=100, label='Risk-Free Asset')
    
    # Plot individual assets if names are provided
    if asset_names is not None:
        asset_returns = np.array([ef_results['weights'][0][i] * ef_results['returns'][0] for i in range(len(asset_names))])
        asset_vols = np.array([ef_results['weights'][0][i] * ef_results['volatilities'][0] for i in range(len(asset_names))])
        plt.scatter(asset_vols, asset_returns, marker='D', color='blue', s=100, label='Individual Assets')
    
    plt.title(title)
    plt.xlabel('Annualized Volatility')
    plt.ylabel('Annualized Expected Return')
    plt.colorbar(label='Sharpe Ratio')
    plt.legend()
    plt.grid(True)
    
    return plt

# Jobson and Korkie (1981) test for equality of Sharpe ratios
# Jobson and Korkie (1981) test for equality of Sharpe ratios
def jobson_korkie_test(returns1, weights1, returns2, weights2, risk_free_rate):
    """
    Implement the Jobson and Korkie (1981) test for equality of Sharpe ratios.
    Returns the test statistic and p-value.
    """
    # Calculate Sharpe ratios
    mean1 = np.sum(returns1.mean() * weights1) * 12
    std1 = np.sqrt(np.dot(weights1.T, np.dot(returns1.cov() * 12, weights1)))
    sharpe1 = (mean1 - risk_free_rate) / std1
    
    mean2 = np.sum(returns2.mean() * weights2) * 12
    std2 = np.sqrt(np.dot(weights2.T, np.dot(returns2.cov() * 12, weights2)))
    sharpe2 = (mean2 - risk_free_rate) / std2
    
    # Calculate portfolio returns
    port_returns1 = np.sum(returns1 * weights1, axis=1)
    port_returns2 = np.sum(returns2 * weights2, axis=1)
    
    # Calculate required statistics for test
    T1 = returns1.shape[0]  # Sample size of first period
    T2 = returns2.shape[0]  # Sample size of second period
    
    # Use statistics from each period individually, not covariance between periods
    sigma1_squared = np.var(port_returns1, ddof=1)
    sigma2_squared = np.var(port_returns2, ddof=1)
    
    # Since these are separate time periods, correlation should be zero
    # so we can set sigma12 to 0
    sigma12 = 0
    
    mu1 = np.mean(port_returns1)
    mu2 = np.mean(port_returns2)
    
    # Calculate the test statistic as per Jobson and Korkie (1981)
    theta = sharpe1 - sharpe2
    
    # Modified asymptotic variance calculation
    # Use average of the two sample sizes for approximate degrees of freedom
    T_avg = (T1 + T2) / 2
    
    avar = (1/T_avg) * (2 * sigma1_squared * sigma2_squared - 2 * sigma1_squared * sigma2_squared * (sigma12 / (sigma1_squared * sigma2_squared)) + 
                   0.5 * (mu1**2 * sigma2_squared**2 / sigma1_squared) + 0.5 * (mu2**2 * sigma1_squared**2 / sigma2_squared))
    
    z_stat = theta / np.sqrt(avar)
    p_value = 2 * (1 - stats.norm.cdf(abs(z_stat)))  # Two-tailed test
    
    return z_stat, p_value


# Ledoit-Wolf test for equality of Sharpe ratios
# Ledoit-Wolf test for equality of Sharpe ratios
def ledoit_wolf_test(returns1, weights1, returns2, weights2, risk_free_rate, block_size=5):
    """
    Implement the Ledoit and Wolf (2008) test for equality of Sharpe ratios.
    This is a simplified implementation and might need adjustment for exact replication.
    """
    # Calculate portfolio returns
    port_returns1 = np.sum(returns1 * weights1, axis=1)
    port_returns2 = np.sum(returns2 * weights2, axis=1)
    
    # Adjust returns by risk-free rate
    excess_returns1 = port_returns1 - risk_free_rate/12  # Monthly risk-free rate
    excess_returns2 = port_returns2 - risk_free_rate/12
    
    # Calculate Sharpe ratios
    sharpe1 = np.mean(excess_returns1) / np.std(excess_returns1, ddof=1) * np.sqrt(12)  # Annualized
    sharpe2 = np.mean(excess_returns2) / np.std(excess_returns2, ddof=1) * np.sqrt(12)
    
    # Calculate difference in Sharpe ratios
    diff_sharpe = sharpe1 - sharpe2
    
    # Bootstrap each period separately to estimate standard error
    T1 = len(excess_returns1)
    T2 = len(excess_returns2)
    n_blocks1 = int(np.ceil(T1 / block_size))
    n_blocks2 = int(np.ceil(T2 / block_size))
    n_bootstrap = 1000
    bootstrap_diffs = np.zeros(n_bootstrap)
    
    for b in range(n_bootstrap):
        # Generate random block starts for first period
        block_starts1 = np.random.randint(0, T1, n_blocks1)
        indices1 = []
        for start in block_starts1:
            end = min(start + block_size, T1)
            indices1.extend(range(start, end))
        indices1 = indices1[:T1]  # Trim if we generated too many indices
        
        # Generate random block starts for second period
        block_starts2 = np.random.randint(0, T2, n_blocks2)
        indices2 = []
        for start in block_starts2:
            end = min(start + block_size, T2)
            indices2.extend(range(start, end))
        indices2 = indices2[:T2]  # Trim if we generated too many indices
        
        # Bootstrap samples
        boot_returns1 = excess_returns1.iloc[indices1] if isinstance(excess_returns1, pd.Series) else excess_returns1[indices1]
        boot_returns2 = excess_returns2.iloc[indices2] if isinstance(excess_returns2, pd.Series) else excess_returns2[indices2]
        
        # Calculate bootstrap Sharpe ratios
        boot_sharpe1 = np.mean(boot_returns1) / np.std(boot_returns1, ddof=1) * np.sqrt(12)
        boot_sharpe2 = np.mean(boot_returns2) / np.std(boot_returns2, ddof=1) * np.sqrt(12)
        
        bootstrap_diffs[b] = boot_sharpe1 - boot_sharpe2
    
    # Standard error of the difference
    se_diff = np.std(bootstrap_diffs, ddof=1)
    
    # Calculate test statistic
    t_stat = diff_sharpe / se_diff
    
    # Calculate p-value
    p_value = 2 * (1 - stats.norm.cdf(abs(t_stat)))  # Two-tailed test
    
    return t_stat, p_value



# Main function for Question 7
def question_7(excel_file, risk_free_rate=0.04):
    """
    Re-estimate the monthly frontiers for the 17 industry portfolios and for the Fama/French 
    5 Factors (2x3) mimicking portfolios over two contiguous periods, one ending in December 2002 
    and the other one ending in December 2024, including the risk-free asset.
    """
    # Load the data
    industry_portfolios, ff_factors = prepare_data(excel_file)
    
    # Split the data into two periods: until Dec 2002 and until Dec 2024
    first_period_end = '2002-12-31'
    second_period_end = '2024-12-31'
    
    # Filter for the first period (up to Dec 2002)
    industry_first_period = industry_portfolios[industry_portfolios.index <= first_period_end]
    ff_first_period = None if ff_factors is None else ff_factors[ff_factors.index <= first_period_end]
    
    # Filter for the second period (Jan 2003 to Dec 2024)
    industry_second_period = industry_portfolios[(industry_portfolios.index > first_period_end) & 
                                               (industry_portfolios.index <= second_period_end)]
    ff_second_period = None if ff_factors is None else ff_factors[(ff_factors.index > first_period_end) & 
                                                                (ff_factors.index <= second_period_end)]
    
    # Convert returns to decimals (if they're in percentages)
    if industry_first_period.mean().mean() > 1:
        industry_first_period = industry_first_period / 100
    if industry_second_period.mean().mean() > 1:
        industry_second_period = industry_second_period / 100
    
    if ff_factors is not None:
        if ff_first_period.mean().mean() > 1:
            ff_first_period = ff_first_period / 100
        if ff_second_period.mean().mean() > 1:
            ff_second_period = ff_second_period / 100
    
    # Generate efficient frontiers for industry portfolios - first period
    industry_ef_first = efficient_frontier(industry_first_period, risk_free_rate)
    
    # Generate efficient frontiers for FF factors - first period (if available)
    ff_ef_first = None
    if ff_factors is not None:
        ff_ef_first = efficient_frontier(ff_first_period, risk_free_rate)
    
    # Plot the efficient frontiers for the first period
    plot_industry_first = plot_efficient_frontier(industry_ef_first, 
                                                  "Efficient Frontier for Industry Portfolios (Until Dec 2002)",
                                                  industry_first_period.columns)
    plot_industry_first.savefig('industry_ef_first_period.png')
    
    if ff_factors is not None:
        plot_ff_first = plot_efficient_frontier(ff_ef_first, 
                                              "Efficient Frontier for Fama-French Factors (Until Dec 2002)",
                                              ff_first_period.columns)
        plot_ff_first.savefig('ff_ef_first_period.png')
    
    # Select portfolios for comparison
    # 1. Tangency portfolio from industry frontier
    industry_tangency_weights = industry_ef_first['optimal_weights']
    
    # 2. Minimum variance portfolio from industry frontier
    industry_min_var_weights = industry_ef_first['min_var_weights']
    
    # 3. Tangency portfolio from FF factors frontier (if available)
    ff_tangency_weights = None
    if ff_factors is not None:
        ff_tangency_weights = ff_ef_first['optimal_weights']
    
    # Calculate Sharpe ratios for the first period
    industry_tangency_sharpe_first = calculate_sharpe_ratio(industry_first_period, industry_tangency_weights, risk_free_rate)
    industry_min_var_sharpe_first = calculate_sharpe_ratio(industry_first_period, industry_min_var_weights, risk_free_rate)
    
    ff_tangency_sharpe_first = None
    if ff_factors is not None:
        ff_tangency_sharpe_first = calculate_sharpe_ratio(ff_first_period, ff_tangency_weights, risk_free_rate)
    
    # Calculate Sharpe ratios for the second period using the same weights
    industry_tangency_sharpe_second = calculate_sharpe_ratio(industry_second_period, industry_tangency_weights, risk_free_rate)
    industry_min_var_sharpe_second = calculate_sharpe_ratio(industry_second_period, industry_min_var_weights, risk_free_rate)
    
    ff_tangency_sharpe_second = None
    if ff_factors is not None:
        ff_tangency_sharpe_second = calculate_sharpe_ratio(ff_second_period, ff_tangency_weights, risk_free_rate)
    
    # Generate efficient frontiers for the second period
    industry_ef_second = efficient_frontier(industry_second_period, risk_free_rate)
    
    ff_ef_second = None
    if ff_factors is not None:
        ff_ef_second = efficient_frontier(ff_second_period, risk_free_rate)
    
    # Plot the efficient frontiers for the second period
    plot_industry_second = plot_efficient_frontier(industry_ef_second, 
                                                 "Efficient Frontier for Industry Portfolios (Jan 2003 - Dec 2024)",
                                                 industry_second_period.columns)
    plot_industry_second.savefig('industry_ef_second_period.png')
    
    if ff_factors is not None:
        plot_ff_second = plot_efficient_frontier(ff_ef_second, 
                                               "Efficient Frontier for Fama-French Factors (Jan 2003 - Dec 2024)",
                                               ff_second_period.columns)
        plot_ff_second.savefig('ff_ef_second_period.png')
    
    # Check if the selected portfolios remain on the efficient frontier in the second period
    # We can do this by plotting these portfolios on the second period's efficient frontier
    
    # Calculate returns and volatilities of the selected portfolios in the second period
    industry_tangency_return_second, industry_tangency_vol_second = calculate_portfolio_stats(
        industry_second_period, industry_tangency_weights)
    
    industry_min_var_return_second, industry_min_var_vol_second = calculate_portfolio_stats(
        industry_second_period, industry_min_var_weights)
    
    # Plot the selected portfolios on the second period's efficient frontier
    plt.figure(figsize=(12, 8))
    
    # Plot the efficient frontier for the second period
    plt.scatter(industry_ef_second['volatilities'], industry_ef_second['returns'], 
                c=industry_ef_second['returns']/industry_ef_second['volatilities'], 
                cmap='viridis', marker='o', s=10, alpha=0.3)
    
    # Plot the optimal portfolio for the second period
    plt.scatter(industry_ef_second['optimal_volatility'], industry_ef_second['optimal_return'], 
                marker='*', color='r', s=300, label='Second Period Tangency Portfolio')
    
    # Plot the minimum variance portfolio for the second period
    plt.scatter(industry_ef_second['min_var_volatility'], industry_ef_second['min_var_return'], 
                marker='P', color='g', s=200, label='Second Period Min Var Portfolio')
    
    # Plot the Capital Allocation Line for the second period
    plt.plot(industry_ef_second['cal_x'], industry_ef_second['cal_y'], 'k--', label='Second Period CAL')
    
    # Plot the first period's tangency portfolio on the second period frontier
    plt.scatter(industry_tangency_vol_second, industry_tangency_return_second, 
                marker='*', color='purple', s=300, label='First Period Tangency Portfolio')
    
    # Plot the first period's minimum variance portfolio on the second period frontier
    plt.scatter(industry_min_var_vol_second, industry_min_var_return_second, 
                marker='P', color='orange', s=200, label='First Period Min Var Portfolio')
    
    plt.title("Comparison of First Period Portfolios on Second Period Frontier")
    plt.xlabel('Annualized Volatility')
    plt.ylabel('Annualized Expected Return')
    plt.colorbar(label='Sharpe Ratio')
    plt.legend()
    plt.grid(True)
    plt.savefig('portfolio_comparison.png')
    
    # Conduct Jobson and Korkie test for equality of Sharpe ratios
    jk_tangency_stat, jk_tangency_pvalue = jobson_korkie_test(
        industry_first_period, industry_tangency_weights,
        industry_second_period, industry_tangency_weights,
        risk_free_rate
    )
    
    jk_min_var_stat, jk_min_var_pvalue = jobson_korkie_test(
        industry_first_period, industry_min_var_weights,
        industry_second_period, industry_min_var_weights,
        risk_free_rate
    )
    
    # Conduct Ledoit-Wolf test for equality of Sharpe ratios
    lw_tangency_stat, lw_tangency_pvalue = ledoit_wolf_test(
        industry_first_period, industry_tangency_weights,
        industry_second_period, industry_tangency_weights,
        risk_free_rate
    )
    
    lw_min_var_stat, lw_min_var_pvalue = ledoit_wolf_test(
        industry_first_period, industry_min_var_weights,
        industry_second_period, industry_min_var_weights,
        risk_free_rate
    )
    
    # Prepare results summary
    results = {
        'Industry Tangency Portfolio': {
            'First Period Sharpe': industry_tangency_sharpe_first,
            'Second Period Sharpe': industry_tangency_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_tangency_stat,
            'Jobson-Korkie p-value': jk_tangency_pvalue,
            'Ledoit-Wolf Test Statistic': lw_tangency_stat,
            'Ledoit-Wolf p-value': lw_tangency_pvalue,
            'Weights': pd.Series(industry_tangency_weights, index=industry_first_period.columns)
        },
        'Industry Min Var Portfolio': {
            'First Period Sharpe': industry_min_var_sharpe_first,
            'Second Period Sharpe': industry_min_var_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_min_var_stat,
            'Jobson-Korkie p-value': jk_min_var_pvalue,
            'Ledoit-Wolf Test Statistic': lw_min_var_stat,
            'Ledoit-Wolf p-value': lw_min_var_pvalue,
            'Weights': pd.Series(industry_min_var_weights, index=industry_first_period.columns)
        }
    }
    
    # Add FF tangency portfolio results if available
    if ff_factors is not None:
        jk_ff_stat, jk_ff_pvalue = jobson_korkie_test(
            ff_first_period, ff_tangency_weights,
            ff_second_period, ff_tangency_weights,
            risk_free_rate
        )
        
        lw_ff_stat, lw_ff_pvalue = ledoit_wolf_test(
            ff_first_period, ff_tangency_weights,
            ff_second_period, ff_tangency_weights,
            risk_free_rate
        )
        
        results['FF Tangency Portfolio'] = {
            'First Period Sharpe': ff_tangency_sharpe_first,
            'Second Period Sharpe': ff_tangency_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_ff_stat,
            'Jobson-Korkie p-value': jk_ff_pvalue,
            'Ledoit-Wolf Test Statistic': lw_ff_stat,
            'Ledoit-Wolf p-value': lw_ff_pvalue,
            'Weights': pd.Series(ff_tangency_weights, index=ff_first_period.columns)
        }
    
    return results

# Main function for Question 8
def question_8(excel_file, risk_free_rate=0.04):
    """
    Repeat the analysis from Question 7 with added constraints or alternative methods.
    """
    # Load the data
    industry_portfolios, ff_factors = prepare_data(excel_file)
    
    # Split the data into two periods: until Dec 2002 and until Dec 2024
    first_period_end = '2002-12-31'
    second_period_end = '2024-12-31'
    
    # Filter for the first period (up to Dec 2002)
    industry_first_period = industry_portfolios[industry_portfolios.index <= first_period_end]
    
    # Filter for the second period (Jan 2003 to Dec 2024)
    industry_second_period = industry_portfolios[(industry_portfolios.index > first_period_end) & 
                                               (industry_portfolios.index <= second_period_end)]
    
    # Convert returns to decimals (if they're in percentages)
    if industry_first_period.mean().mean() > 1:
        industry_first_period = industry_first_period / 100
    if industry_second_period.mean().mean() > 1:
        industry_second_period = industry_second_period / 100
    
    # Approach 1: Global Minimum Variance Portfolio (without short selling)
    def gmvp_objective(weights, cov_matrix):
        return np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    
    n_assets = industry_first_period.shape[1]
    
    # Constraints: weights sum to 1
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    
    # Bounds: no short selling (0 <= weight <= 1)
    bounds = tuple((0, 1) for _ in range(n_assets))
    
    # Initial guess: equal weights
    initial_weights = np.array([1.0 / n_assets] * n_assets)
    
    # Optimize for GMVP
    cov_matrix_first = industry_first_period.cov()
    
    gmvp_result = minimize(gmvp_objective, initial_weights, 
                          args=(cov_matrix_first,), 
                          method='SLSQP', 
                          bounds=bounds, 
                          constraints=constraints)
    
    gmvp_weights = gmvp_result['x']
    
    # Calculate GMVP stats for first period
    gmvp_return_first = np.sum(industry_first_period.mean() * gmvp_weights) * 12
    gmvp_vol_first = np.sqrt(np.dot(gmvp_weights.T, np.dot(cov_matrix_first * 12, gmvp_weights)))
    gmvp_sharpe_first = (gmvp_return_first - risk_free_rate) / gmvp_vol_first
    
    # Calculate GMVP stats for second period
    cov_matrix_second = industry_second_period.cov()
    gmvp_return_second = np.sum(industry_second_period.mean() * gmvp_weights) * 12
    gmvp_vol_second = np.sqrt(np.dot(gmvp_weights.T, np.dot(cov_matrix_second * 12, gmvp_weights)))
    gmvp_sharpe_second = (gmvp_return_second - risk_free_rate) / gmvp_vol_second
    
    # Approach 2: Equally-Weighted Portfolio (1/N strategy)
    equal_weights = np.array([1.0 / n_assets] * n_assets)
    
    # Calculate Equal-Weight stats for first period
    equal_return_first = np.sum(industry_first_period.mean() * equal_weights) * 12
    equal_vol_first = np.sqrt(np.dot(equal_weights.T, np.dot(cov_matrix_first * 12, equal_weights)))
    equal_sharpe_first = (equal_return_first - risk_free_rate) / equal_vol_first

    # Calculate Equal-Weight stats for second period
    equal_return_second = np.sum(industry_second_period.mean() * equal_weights) * 12
    equal_vol_second = np.sqrt(np.dot(equal_weights.T, np.dot(cov_matrix_second * 12, equal_weights)))
    equal_sharpe_second = (equal_return_second - risk_free_rate) / equal_vol_second
    
    # Approach 3: Robust Optimization - Resampled Efficient Frontier
    # Implement a simple resampling approach
    n_samples = 1000
    resampled_weights = np.zeros((n_samples, n_assets))
    
    for i in range(n_samples):
        # Resample returns with replacement
        sample_indices = np.random.choice(len(industry_first_period), size=len(industry_first_period), replace=True)
        resampled_returns = industry_first_period.iloc[sample_indices]
        
        # Optimize for the tangency portfolio on the resampled data
        resampled_cov = resampled_returns.cov()
        resampled_mean = resampled_returns.mean()
        
        # Function to minimize negative Sharpe Ratio
        def neg_sharpe_ratio(weights, mean_returns, cov_matrix):
            portfolio_return = np.sum(mean_returns * weights) * 12
            portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(cov_matrix * 12, weights)))
            sharpe = (portfolio_return - risk_free_rate) / portfolio_volatility
            return -sharpe
        
        # Optimize for this sample
        res = minimize(neg_sharpe_ratio, initial_weights, 
                      args=(resampled_mean, resampled_cov), 
                      method='SLSQP', 
                      bounds=bounds, 
                      constraints=constraints)
        
        resampled_weights[i, :] = res['x']
    
    # Average the weights to get the resampled efficient portfolio weights
    robust_weights = np.mean(resampled_weights, axis=0)
    
    # Normalize to ensure weights sum to 1
    robust_weights = robust_weights / np.sum(robust_weights)
    
    # Calculate Robust Portfolio stats for first period
    robust_return_first = np.sum(industry_first_period.mean() * robust_weights) * 12
    robust_vol_first = np.sqrt(np.dot(robust_weights.T, np.dot(cov_matrix_first * 12, robust_weights)))
    robust_sharpe_first = (robust_return_first - risk_free_rate) / robust_vol_first
    
    # Calculate Robust Portfolio stats for second period
    robust_return_second = np.sum(industry_second_period.mean() * robust_weights) * 12
    robust_vol_second = np.sqrt(np.dot(robust_weights.T, np.dot(cov_matrix_second * 12, robust_weights)))
    robust_sharpe_second = (robust_return_second - risk_free_rate) / robust_vol_second
    
    # Statistical tests for the alternative approaches
    # Jobson-Korkie test
    jk_gmvp_stat, jk_gmvp_pvalue = jobson_korkie_test(
        industry_first_period, gmvp_weights,
        industry_second_period, gmvp_weights,
        risk_free_rate
    )
    
    jk_equal_stat, jk_equal_pvalue = jobson_korkie_test(
        industry_first_period, equal_weights,
        industry_second_period, equal_weights,
        risk_free_rate
    )
    
    jk_robust_stat, jk_robust_pvalue = jobson_korkie_test(
        industry_first_period, robust_weights,
        industry_second_period, robust_weights,
        risk_free_rate
    )
    
    # Ledoit-Wolf test
    lw_gmvp_stat, lw_gmvp_pvalue = ledoit_wolf_test(
        industry_first_period, gmvp_weights,
        industry_second_period, gmvp_weights,
        risk_free_rate
    )
    
    lw_equal_stat, lw_equal_pvalue = ledoit_wolf_test(
        industry_first_period, equal_weights,
        industry_second_period, equal_weights,
        risk_free_rate
    )
    
    lw_robust_stat, lw_robust_pvalue = ledoit_wolf_test(
        industry_first_period, robust_weights,
        industry_second_period, robust_weights,
        risk_free_rate
    )
    
    # Compare these alternative approaches with the efficient frontier in the second period
    # Generate efficient frontier for the second period
    industry_ef_second = efficient_frontier(industry_second_period, risk_free_rate)
    
    # Plot the comparison
    plt.figure(figsize=(12, 8))
    
    # Plot the efficient frontier for the second period
    plt.scatter(industry_ef_second['volatilities'], industry_ef_second['returns'], 
                c=industry_ef_second['returns']/industry_ef_second['volatilities'], 
                cmap='viridis', marker='o', s=10, alpha=0.3)
    
    # Plot the optimal portfolio for the second period
    plt.scatter(industry_ef_second['optimal_volatility'], industry_ef_second['optimal_return'], 
                marker='*', color='r', s=300, label='Second Period Tangency Portfolio')
    
    # Plot the minimum variance portfolio for the second period
    plt.scatter(industry_ef_second['min_var_volatility'], industry_ef_second['min_var_return'], 
                marker='P', color='g', s=200, label='Second Period Min Var Portfolio')
    
    # Plot the alternative portfolios on the second period frontier
    plt.scatter(gmvp_vol_second, gmvp_return_second, 
                marker='D', color='purple', s=150, label='Global Minimum Variance Portfolio')
    
    plt.scatter(equal_vol_second, equal_return_second, 
                marker='s', color='orange', s=150, label='Equally-Weighted Portfolio')
    
    plt.scatter(robust_vol_second, robust_return_second, 
                marker='^', color='blue', s=150, label='Resampled Robust Portfolio')
    
    plt.title("Comparison of Alternative Portfolio Strategies (Second Period)")
    plt.xlabel('Annualized Volatility')
    plt.ylabel('Annualized Expected Return')
    plt.colorbar(label='Sharpe Ratio')
    plt.legend()
    plt.grid(True)
    plt.savefig('alternative_portfolios_comparison.png')
    
    # Prepare results summary for the alternative approaches
    alternative_results = {
        'Global Minimum Variance Portfolio': {
            'First Period Sharpe': gmvp_sharpe_first,
            'Second Period Sharpe': gmvp_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_gmvp_stat,
            'Jobson-Korkie p-value': jk_gmvp_pvalue,
            'Ledoit-Wolf Test Statistic': lw_gmvp_stat,
            'Ledoit-Wolf p-value': lw_gmvp_pvalue,
            'Weights': pd.Series(gmvp_weights, index=industry_first_period.columns)
        },
        'Equally-Weighted Portfolio': {
            'First Period Sharpe': equal_sharpe_first,
            'Second Period Sharpe': equal_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_equal_stat,
            'Jobson-Korkie p-value': jk_equal_pvalue,
            'Ledoit-Wolf Test Statistic': lw_equal_stat,
            'Ledoit-Wolf p-value': lw_equal_pvalue,
            'Weights': pd.Series(equal_weights, index=industry_first_period.columns)
        },
        'Resampled Robust Portfolio': {
            'First Period Sharpe': robust_sharpe_first,
            'Second Period Sharpe': robust_sharpe_second,
            'Jobson-Korkie Test Statistic': jk_robust_stat,
            'Jobson-Korkie p-value': jk_robust_pvalue,
            'Ledoit-Wolf Test Statistic': lw_robust_stat,
            'Ledoit-Wolf p-value': lw_robust_pvalue,
            'Weights': pd.Series(robust_weights, index=industry_first_period.columns)
        }
    }
    
    return alternative_results

# Main execution function to run both questions
def run_analysis(excel_file='6947830_1804821725_data.xlsx', risk_free_rate=0.04):
    """
    Run the analysis for both Question 7 and Question 8.
    """
    print("Running analysis for Question 7...")
    q7_results = question_7(excel_file, risk_free_rate)
    
    print("\nQuestion 7 Results:")
    for portfolio_name, results in q7_results.items():
        print(f"\n{portfolio_name}:")
        print(f"First Period Sharpe Ratio: {results['First Period Sharpe']:.4f}")
        print(f"Second Period Sharpe Ratio: {results['Second Period Sharpe']:.4f}")
        print(f"Jobson-Korkie Test Statistic: {results['Jobson-Korkie Test Statistic']:.4f}")
        print(f"Jobson-Korkie p-value: {results['Jobson-Korkie p-value']:.4f}")
        print(f"Ledoit-Wolf Test Statistic: {results['Ledoit-Wolf Test Statistic']:.4f}")
        print(f"Ledoit-Wolf p-value: {results['Ledoit-Wolf p-value']:.4f}")
        print("\nPortfolio Weights:")
        print(results['Weights'])
    
    print("\n\nRunning analysis for Question 8...")
    q8_results = question_8(excel_file, risk_free_rate)
    
    print("\nQuestion 8 Results:")
    for portfolio_name, results in q8_results.items():
        print(f"\n{portfolio_name}:")
        print(f"First Period Sharpe Ratio: {results['First Period Sharpe']:.4f}")
        print(f"Second Period Sharpe Ratio: {results['Second Period Sharpe']:.4f}")
        print(f"Jobson-Korkie Test Statistic: {results['Jobson-Korkie Test Statistic']:.4f}")
        print(f"Jobson-Korkie p-value: {results['Jobson-Korkie p-value']:.4f}")
        print(f"Ledoit-Wolf Test Statistic: {results['Ledoit-Wolf Test Statistic']:.4f}")
        print(f"Ledoit-Wolf p-value: {results['Ledoit-Wolf p-value']:.4f}")
        print("\nPortfolio Weights:")
        print(results['Weights'])
    
    print("\nAnalysis complete. Please check the generated plots.")
    return q7_results, q8_results

# If this script is run directly, execute the analysis
if __name__ == "__main__":
    run_analysis()