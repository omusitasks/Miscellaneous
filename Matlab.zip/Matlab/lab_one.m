% QUESTION 1

% Load data from Excel with 'VariableNamingRule' set to 'preserve'
filename = 'DPL1_Raw_Data.xlsx';
air_data = readtable(filename, 'Sheet', 'Air', 'VariableNamingRule', 'preserve');

% Extract the temperature, volume, and pressure columns
temperatures_air = air_data{:, 1};  % First column: Temperature
pressures_air = air_data{:, 2:end}; % Remaining columns: Pressures at different volumes

% Display available temperature values for debugging
disp('Available temperature values:');
disp(temperatures_air);

% Check the size of pressures_air
disp('Size of pressures_air:');
disp(size(pressures_air));

% Volume labels for each pressure column (manually verified)
% Update this to match the number of pressure measurements
if size(pressures_air, 2) == 15
    volume_labels_air = [0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9]; 
else
    volume_labels_air = [0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1]; 
end

% Convert from liters to cubic meters (1 L = 0.001 m³)
volumes_air = volume_labels_air * 0.001;

% Check the size of volumes_air
disp('Size of volumes_air:');
disp(length(volumes_air));

% Plot Boyle's Law: P vs V for Air at different temperatures
figure;
hold on;

% Plot for T = 50°C, using a range to avoid precision issues
tolerance = 0.5;  % Tolerance for temperature matching
if any(abs(temperatures_air - 50) < tolerance)
    pressure_air_50 = pressures_air(abs(temperatures_air - 50) < tolerance, :);
    disp('Size of pressure_air_50:');
    disp(size(pressure_air_50));
    if length(pressure_air_50) == length(volumes_air)
        plot(volumes_air, pressure_air_50, '-o', 'DisplayName', 'T = 50°C');
    else
        warning('Mismatch between volume and pressure data for T = 50°C');
    end
else
    warning('No data available for temperature 50°C');
end

% Plot for T = 60°C
if any(abs(temperatures_air - 60) < tolerance)
    pressure_air_60 = pressures_air(abs(temperatures_air - 60) < tolerance, :);
    disp('Size of pressure_air_60:');
    disp(size(pressure_air_60));
    if length(pressure_air_60) == length(volumes_air)
        plot(volumes_air, pressure_air_60, '-o', 'DisplayName', 'T = 60°C');
    else
        warning('Mismatch between volume and pressure data for T = 60°C');
    end
else
    warning('No data available for temperature 60°C');
end

% Plot for T = 70°C
if any(abs(temperatures_air - 70) < tolerance)
    pressure_air_70 = pressures_air(abs(temperatures_air - 70) < tolerance, :);
    disp('Size of pressure_air_70:');
    disp(size(pressure_air_70));
    if length(pressure_air_70) == length(volumes_air)
        plot(volumes_air, pressure_air_70, '-o', 'DisplayName', 'T = 70°C');
    else
        warning('Mismatch between volume and pressure data for T = 70°C');
    end
else
    warning('No data available for temperature 70°C');
end

% Add labels and legend
xlabel('Volume (m³)');
ylabel('Pressure (kPa)');
title('Boyle''s Law: P vs V for Air at Different Temperatures');
legend;
grid on;
hold off;



% QUESTION 2

% Load data for CO2 (sheet 2)
filename = 'DPL1_Raw_Data.xlsx';
co2_data = readtable(filename, 'Sheet', 'CO2');

% Extract the temperature, volume, and pressure columns for CO2
temperatures_co2 = co2_data{:, 1}; % Assuming the first column is temperature
pressures_co2 = co2_data{:, 2:end}; % Remaining columns are pressures for different volumes

% Display available temperature values for debugging
disp('Available temperature values for CO2:');
disp(temperatures_co2);

% Volume labels for each pressure column (manually verified)
volume_labels_co2 = {'0.3 L', '0.6 L', '0.9 L', '1.2 L'};

% Check the size of pressures_co2
disp('Size of pressures_co2:');
disp(size(pressures_co2));

% Convert volume labels to numeric for easier comparison
numeric_volumes_co2 = cellfun(@(x) str2double(x(1:end-2)), volume_labels_co2); % Convert from string to double

% Plot Gay-Lussac's Law: P vs T for CO2 at different volumes
figure;
hold on;

% Plot for each volume
for i = 1:length(volume_labels_co2)
    % Check if the pressures_co2 column exists
    if size(pressures_co2, 2) >= i
        plot(temperatures_co2, pressures_co2(:, i), '-o', 'DisplayName', ['V = ' volume_labels_co2{i}]);
    else
        warning(['No data available for volume ' volume_labels_co2{i}]);
    end
end

% Add labels and legend
xlabel('Temperature (°C)');
ylabel('Pressure (kPa)');
title('Gay-Lussac''s Law: P vs T for CO2 at Different Volumes');
legend;
grid on;
hold off;


% Question 3: Calculate the specific gas constant for air, CO2, and N2
% Given data from Appendix B
R_air_accepted = 287;   % J/kg·K
R_CO2_accepted = 188.9; % J/kg·K
R_N2_accepted = 296.8;  % J/kg·K

M_air = 28.97;   % g/mol
M_CO2 = 44.01;   % g/mol
M_N2 = 28.02;    % g/mol

% Ideal gas constant
R = 8.314; % J/mol·K

% Calculating specific gas constant for each gas
R_air_calc = (R / M_air);
R_CO2_calc = (R / M_CO2);
R_N2_calc = (R / M_N2);

% Displaying results for Question 3
fprintf('Question 3:\n');
fprintf('Calculated R for air: %.2f J/kg·K\n', R_air_calc);
fprintf('Calculated R for CO2: %.2f J/kg·K\n', R_CO2_calc);
fprintf('Calculated R for N2: %.2f J/kg·K\n\n', R_N2_calc);

% Question 4: Calculate the percent difference between calculated and accepted values
% Percent difference calculations
diff_R_air = abs(R_air_accepted - R_air_calc) / R_air_accepted * 100;
diff_R_CO2 = abs(R_CO2_accepted - R_CO2_calc) / R_CO2_accepted * 100;
diff_R_N2 = abs(R_N2_accepted - R_N2_calc) / R_N2_accepted * 100;

% Displaying results for Question 4
fprintf('Question 4:\n');
fprintf('Percent difference for air: %.2f%%\n', diff_R_air);
fprintf('Percent difference for CO2: %.2f%%\n', diff_R_CO2);
fprintf('Percent difference for N2: %.2f%%\n\n', diff_R_N2);

% Question 5: Calculate statistical uncertainty using standard error
% Assumed standard deviations for each gas (example values)
std_air = 1.2;
std_CO2 = 1.1;
std_N2 = 1.3;

% Number of samples for each gas
N_air = 10;
N_CO2 = 8;
N_N2 = 12;

uR_air = std_air / sqrt(N_air);
uR_CO2 = std_CO2 / sqrt(N_CO2);
uR_N2 = std_N2 / sqrt(N_N2);

% Displaying results for Question 5
fprintf('Question 5:\n');
fprintf('Statistical uncertainty for air: %.2f J/kg·K\n', uR_air);
fprintf('Statistical uncertainty for CO2: %.2f J/kg·K\n', uR_CO2);
fprintf('Statistical uncertainty for N2: %.2f J/kg·K\n\n', uR_N2);

% Question 6: Calculate the universal gas constant based on all gases
% Universal gas constant calculation across all gases
R_universal = mean([R_air_calc, R_CO2_calc, R_N2_calc]);
uR_universal = std([R_air_calc, R_CO2_calc, R_N2_calc]) / sqrt(3);

% Displaying results for Question 6
fprintf('Question 6:\n');
fprintf('Universal gas constant: %.2f J/kg·K\n', R_universal);
fprintf('Universal gas constant uncertainty: %.2f J/kg·K\n', uR_universal);

